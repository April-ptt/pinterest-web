import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { CreatePin } from './pages/CreatePin';

function App() {
  return (
    <div className="min-h-screen bg-white font-sans">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/create" element={<CreatePin />} />
      </Routes>
    </div>
  );
}

export default App;