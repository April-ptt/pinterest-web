import React from 'react';

export function Home() {
  const pins = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=500&q=80",
      title: "Aesthetic Planet"
    },
    {
      id: 2, 
      image: "https://images.unsplash.com/photo-1467810563316-b5476525c0f9?w=500&q=80",
      title: "Fireworks Display"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1612012460576-5d51b5b04b00?w=500&q=80",
      title: "Book Photography"
    },
    {
      id: 4,
      image: "https://images.unsplash.com/photo-1533450718592-29d45635f0a9?w=500&q=80",
      title: "Minions Art"
    },
    {
      id: 5,
      image: "https://images.unsplash.com/photo-1542596768-5d1d21f1cf98?w=500&q=80",
      title: "Aesthetic Photography"
    }
  ];

  return (
    <main className="pt-20 px-4">
      <div className="flex space-x-2 mb-6 justify-center">
        {['All', 'Cute Wallpapers', 'Hair', 'Coffee', 'Sky', 'Aesthetic'].map((item) => (
          <button
            key={item}
            className="px-4 py-2 rounded-full text-sm hover:bg-gray-100 font-medium tracking-wide"
          >
            {item}
          </button>
        ))}
      </div>

      <div className="columns-2 md:columns-3 lg:columns-4 xl:columns-5 gap-4 mx-auto">
        {pins.map((pin) => (
          <div key={pin.id} className="mb-4 break-inside-avoid">
            <div className="relative group">
              <img
                src={pin.image}
                alt={pin.title}
                className="w-full rounded-2xl"
              />
              <div className="absolute inset-0 bg-black bg-opacity-20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 rounded-2xl flex items-center justify-center">
                <div className="flex space-x-2">
                  <button className="px-4 py-2 bg-red-600 text-white rounded-full text-sm font-semibold">
                    Save
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}