import React, { useState } from 'react';
import { Upload } from 'lucide-react';

export function CreatePin() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedBoard, setSelectedBoard] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    // Handle file drop logic here
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  return (
    <div className="min-h-screen pt-20 px-4 bg-[#e9e9e9]">
      <div className="max-w-[880px] mx-auto bg-white rounded-2xl shadow-sm p-8">
        <div className="flex gap-8">
          {/* Left side - Image upload */}
          <div className="flex-1">
            <div
              className="w-full aspect-[4/5] bg-[#e9e9e9] rounded-lg flex flex-col items-center justify-center cursor-pointer"
              onDrop={handleDrop}
              onDragOver={handleDragOver}
            >
              <Upload className="w-8 h-8 text-gray-400 mb-2" />
              <p className="text-center text-sm text-gray-500">
                Drag and drop or click to upload
              </p>
              <p className="text-center text-xs text-gray-400 mt-2">
                Recommendation: Use high-quality .jpg files less than 20MB
              </p>
            </div>
          </div>

          {/* Right side - Pin details */}
          <div className="flex-1 space-y-6">
            <div>
              <input
                type="text"
                placeholder="Add your title"
                className="w-full text-3xl font-bold border-b border-gray-200 pb-2 focus:outline-none focus:border-gray-400"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div>
              <textarea
                placeholder="Tell everyone what your Pin is about"
                className="w-full h-24 text-base resize-none border-b border-gray-200 pb-2 focus:outline-none focus:border-gray-400"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            <div>
              <select
                className="w-full p-2 border border-gray-200 rounded-lg focus:outline-none focus:border-gray-400"
                value={selectedBoard}
                onChange={(e) => setSelectedBoard(e.target.value)}
              >
                <option value="">Select</option>
                <option value="board1">Board 1</option>
                <option value="board2">Board 2</option>
              </select>
            </div>

            <div>
              <input
                type="text"
                placeholder="Add a destination link"
                className="w-full p-2 border border-gray-200 rounded-lg focus:outline-none focus:border-gray-400"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
              />
            </div>

            <div className="flex justify-end space-x-4">
              <button className="px-4 py-3 rounded-full hover:bg-gray-100">
                Cancel
              </button>
              <button className="px-4 py-3 rounded-full bg-red-600 text-white font-semibold hover:bg-red-700">
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}